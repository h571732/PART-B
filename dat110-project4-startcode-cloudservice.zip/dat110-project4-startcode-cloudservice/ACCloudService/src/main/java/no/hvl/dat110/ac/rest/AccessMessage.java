package no.hvl.dat110.ac.rest;

public class AccessMessage {

	private String message;
	
	public AccessMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
