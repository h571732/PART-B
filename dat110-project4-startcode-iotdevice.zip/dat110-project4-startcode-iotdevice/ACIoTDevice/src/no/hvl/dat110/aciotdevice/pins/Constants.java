package no.hvl.dat110.aciotdevice.pins;

public class Constants {

	public static int LOW = 0;
	public static int HIGH = 1;
	
	public static int INPUT = 0;
	public static int OUTPUT = 1;
	
	public Constants() {
		// TODO Auto-generated constructor stub
	}

}
