package no.hvl.dat110.aciotdevice.client;

public class Configuration {

	public static int port = 8080;
    public static String host = "localhost";

}
